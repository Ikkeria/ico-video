import util
import xbmcaddon

import xbmc

link='rtmp://stream2.france24.yacast.net:80/france24_live/fr playpath=f24_livefr app=france24_live/fr'
xbmc.Player().play(item=link)
